<?php
	$host = "puccini.cs.lth.se";
	$userName = "db38";
	$password = "xat127mk";
	$database = "db38";
?>
